Trabalho da disciplina de PAA realizado por Davi Gomes e Ian Quadrio.

Vá até o diretório TP1 e digite no terminal:

make clean
make
./programa -i entrada0.txt -o saida.txt

O arquivo entrada0.txt é o arquivo de entrada e o saida.txt é o arquivo de saída que vai apresentar os resultados.
